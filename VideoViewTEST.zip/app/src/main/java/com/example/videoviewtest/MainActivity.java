package com.example.videoviewtest;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.VideoView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private VideoView videoView;
    private MediaController mediaController; //재생, 정지버튼
    private static String[] videoURLs={
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131581433843755/a12cc3083bf8e862.mp4?ex=66e9278d&is=66e7d60d&hm=712c7ae5b93ab7d21c608aca2ff8a5905f6634d961a0f211d692d7e5406fc785&",
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131641219452959/videoplayback_4.mp4?ex=66e9279b&is=66e7d61b&hm=0c73bc8980d5e0eae9a86a42a8ffd9bd57eb068072257fea0181887a86e911d8&",
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131641911509072/videoplayback_3.mp4?ex=66e9279c&is=66e7d61c&hm=90494278289cf9ce73b4d9c75a6d2737e1db209d3625673a7e2def8286c91628&",
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131642272223232/videoplayback_2.mp4?ex=66e9279c&is=66e7d61c&hm=4c772c3c34cf551a985126795e57f0a5a87e2b707b2518d9b8dcb3b55167c33f&",
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131642863616031/videoplayback_1.mp4?ex=66e9279c&is=66e7d61c&hm=32ddb5968b4d3ddbffde1b552a2a5612bd246235e9332ce6e8bb4c578d50ff88&",
            "https://cdn.discordapp.com/attachments/768021042429558806/1285131643388166174/videoplayback.mp4?ex=66e9279c&is=66e7d61c&hm=c051ffb3d3ffb35ed4d41e2f6d5bf11b7b1f447883349e0c73fbf4981bb3caf7&"
    };

    public String randomURL(){
        Random random = new Random();
        int index = random.nextInt(videoURLs.length);
        return videoURLs[index];
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        videoView=findViewById(R.id.videoView);

        mediaController=new MediaController(this);
        mediaController.setAnchorView(videoView);
        Uri uri=Uri.parse(randomURL());
        videoView.setMediaController(mediaController);
        videoView.setVideoURI(uri);

        videoView.start();

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoView.start();
            }
        });

        videoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(randomURL());
                videoView.setVideoURI(uri);
                videoView.start();
            }
        });
    }
}